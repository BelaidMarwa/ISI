public class Main {
    public static void main(String[] args) {
      System.out.println(" ######### DEBUT #############");
      System.out.println(" Bonnes vacances !");
      System.out.println(" ######### FIN #############");
    }
}
